package com.guard.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import java.util.Date

class AdminReceiver : DeviceAdminReceiver() {
    override fun onPasswordFailed(context: Context, intent: Intent) {
        val p = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val n = p.getInt("fail_count", 0) + 1
        p.edit().putInt("fail_count", n).putString("evt", "#$n - ${Date()}").apply()
        if (!p.getBoolean("on", false)) return
        val s = GuardService.instance
        if (s != null) {
            s.snap()
        } else {
            // Service kisi wajah se mar chuki thi: usse dobara zinda karo aur ye koshish bhi na chhootay
            context.startForegroundService(Intent(context, GuardService::class.java))
            Thread {
                Thread.sleep(800)
                GuardService.instance?.snap() ?: Mailer.sendWithRetry(context.applicationContext, null, null)
            }.start()
        }
    }
}
