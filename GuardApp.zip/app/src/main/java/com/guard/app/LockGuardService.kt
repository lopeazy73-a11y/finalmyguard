package com.guard.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Date

class LockGuardService : AccessibilityService() {
    // In cheezon par mushtamil kisi bhi window/panel ko foran band kar dete hain
    private val badWindow = listOf(
        "globalactions", "powermenu", "shutdown", "poweroff", "power_off",
        "airplane", "networkdialog", "internetdialog", "qs_internet", "wificonnect"
    )
    private val badText = setOf(
        "power off", "restart", "shut down", "shutdown", "reboot",
        "power off & restart", "emergency restart",
        "airplane mode", "flight mode", "airplane",
        "wi-fi", "wifi", "internet", "mobile data", "mobile network", "cellular data"
    )
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        getSharedPreferences("cfg", 0).edit().putString("acc", Date().toString()).apply()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val p = getSharedPreferences("cfg", 0)
        if (!p.getBoolean("on", false)) return
        if (!getSystemService(KeyguardManager::class.java).isKeyguardLocked) return

        val cls = (e.className?.toString() ?: "").lowercase()
        val pkg = (e.packageName?.toString() ?: "").lowercase()
        var hit = badWindow.any { cls.contains(it) }

        if (!hit && pkg.contains("systemui")) {
            hit = scanAll()
        }
        if (hit) dismissRepeated()
    }

    private fun scanAll(): Boolean {
        if (scan(rootInActiveWindow, 0)) return true
        try {
            for (w in windows) if (scan(w.root, 0)) return true
        } catch (ex: Exception) {}
        return false
    }

    private fun scan(n: AccessibilityNodeInfo?, d: Int): Boolean {
        if (n == null || d > 16) return false
        val t = n.text?.toString()?.trim()?.lowercase()
        val c = n.contentDescription?.toString()?.trim()?.lowercase()
        if ((t != null && t in badText) || (c != null && c in badText)) return true
        for (i in 0 until n.childCount) if (scan(n.getChild(i), d + 1)) return true
        return false
    }

    // Ek dafa back/home kaafi na ho to turant dobara koshish karte hain
    private fun dismissRepeated() {
        getSharedPreferences("cfg", 0).edit().putString("blk", Date().toString()).apply()
        performGlobalAction(GLOBAL_ACTION_BACK)
        performGlobalAction(GLOBAL_ACTION_HOME)
        h.postDelayed({ if (scanAll()) { performGlobalAction(GLOBAL_ACTION_BACK); performGlobalAction(GLOBAL_ACTION_HOME) } }, 120)
        h.postDelayed({ if (scanAll()) { performGlobalAction(GLOBAL_ACTION_BACK); performGlobalAction(GLOBAL_ACTION_HOME) } }, 350)
    }

    override fun onInterrupt() {}
}
