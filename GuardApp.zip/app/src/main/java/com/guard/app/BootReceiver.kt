package com.guard.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

// Phone restart hone par, agar Protection pehle se ON thi, to khud ba khud dobara chalu kar deta hai
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val p = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            if (p.getBoolean("on", false)) {
                context.startForegroundService(Intent(context, GuardService::class.java))
            }
        }
    }
}
