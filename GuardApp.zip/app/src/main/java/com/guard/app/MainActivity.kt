package com.guard.app

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.*
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private lateinit var st: TextView
    private val autoH = Handler(Looper.getMainLooper())
    private val autoTick = object : Runnable {
        override fun run() { refresh(); autoH.postDelayed(this, 3000) }
    }
    private val navy = Color.parseColor("#1B2A4A")
    private val teal = Color.parseColor("#13B8A6")
    private val amber = Color.parseColor("#F5A623")
    private val red = Color.parseColor("#E5484D")
    private val cardBg = Color.parseColor("#F4F6FB")
    private val bgTop = Color.parseColor("#EAF6F3")

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun pill(c: Int) = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(c) }

    private fun section(title: String, root: LinearLayout) {
        TextView(this).apply {
            text = title; setTextColor(navy); textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(18), 0, dp(6))
            root.addView(this)
        }
    }

    private fun card(root: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(cardBg) }
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        root.addView(c)
        return c
    }

    private fun et(hint: String, key: String, p: android.content.SharedPreferences, holder: LinearLayout, pw: Boolean = false): EditText {
        val e = EditText(this).apply {
            this.hint = hint; setText(p.getString(key, ""))
            setTextColor(navy); setHintTextColor(Color.parseColor("#8A94A6"))
            if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat(); setColor(Color.WHITE)
                setStroke(dp(1), Color.parseColor("#D7DEEC"))
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        holder.addView(e)
        return e
    }

    private fun btn(text: String, color: Int, holder: LinearLayout, a: () -> Unit): Button {
        val b = Button(this).apply {
            this.text = text; isAllCaps = false; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD); textSize = 14f
            background = pill(color)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            layoutParams = lp
            stateListAnimator = null
            setOnClickListener { a() }
        }
        holder.addView(b)
        return b
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", 0)
        val outer = ScrollView(this).apply { setBackgroundColor(bgTop) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(40))
        }
        outer.addView(root)

        TextView(this).apply {
            text = "🛡  Guard"
            setTextColor(navy); textSize = 26f; setTypeface(typeface, Typeface.BOLD)
            root.addView(this)
        }
        TextView(this).apply {
            text = "Aap ka phone, aap ki nigrani mein"
            setTextColor(Color.parseColor("#5B6B8C")); textSize = 13f
            setPadding(0, dp(2), 0, 0)
            root.addView(this)
        }

        section("EMAIL SETUP", root)
        val c1 = card(root)
        val from = et("Gmail address (bhejne wala)", "from", p, c1)
        val pass = et("Gmail App Password (16 letters)", "pass", p, c1, true)
        val to = et("Photo kis email par aye (khali = wohi)", "to", p, c1)

        fun save() {
            val pw = pass.text.toString().replace(" ", "")
            p.edit().putString("from", from.text.toString().trim()).putString("pass", pw)
                .putString("to", to.text.toString().trim()).apply()
            if (pw.length != 16) Toast.makeText(this, "Dhyan: App Password 16 letters ka hota hai, aap ka ${pw.length} ka hai", Toast.LENGTH_LONG).show()
        }

        section("SETUP STEPS", root)
        val c2 = card(root)
        btn("1 ・ Permissions do", navy, c2) {
            requestPermissions(arrayOf(android.Manifest.permission.CAMERA,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("2 ・ Device Admin ON karo", navy, c2) {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java)))
        }
        btn("3 ・ Accessibility ON karo", navy, c2) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Installed apps > Guard > ON", Toast.LENGTH_LONG).show()
        }
        btn("4 ・ Battery: Unrestricted karo", navy, c2) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }

        section("PROTECTION", root)
        val c3 = card(root)
        btn("▶  START Protection", teal, c3) {
            save(); p.edit().putBoolean("on", true).apply()
            startForegroundService(Intent(this, GuardService::class.java))
            Toast.makeText(this, "Protection chalu", Toast.LENGTH_SHORT).show()
            refresh()
        }
        btn("■  STOP Protection", red, c3) {
            p.edit().putBoolean("on", false).apply()
            stopService(Intent(this, GuardService::class.java))
            refresh()
        }
        btn("✉  TEST: abhi photo + email bhejo", amber, c3) {
            save()
            val s = GuardService.instance
            if (s == null) Toast.makeText(this, "Pehle Protection START karo", Toast.LENGTH_LONG).show()
            else { s.snap(); Toast.makeText(this, "Bhej raha hoon, 1 minute baad Status refresh karo", Toast.LENGTH_LONG).show() }
        }

        section("STATUS", root)
        val c4 = card(root)
        st = TextView(this).apply { textSize = 14f; setTextColor(navy); setLineSpacing(dp(6).toFloat(), 1f) }
        c4.addView(st)
        btn("↻  Status refresh", Color.parseColor("#5B6B8C"), c4) { refresh() }

        setContentView(outer)
    }

    override fun onResume() { super.onResume(); autoH.removeCallbacks(autoTick); autoH.post(autoTick) }
    override fun onPause() { super.onPause(); autoH.removeCallbacks(autoTick) }

    private fun dot(ok: Boolean) = if (ok) "🟢" else "🔴"

    private fun refresh() {
        val p = getSharedPreferences("cfg", 0)
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)
        val cam = checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val loc = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val running = GuardService.instance != null
        st.text = "${dot(admin)} Device Admin\n${dot(acc)} Accessibility\n${dot(cam)} Camera permission\n" +
            "${dot(loc)} Location permission\n${dot(running)} Protection chal rahi\n\n" +
            "🔔 Aakhri ghalat PIN: ${p.getString("evt", "kabhi nahi")}\n" +
            "🚫 Aakhri block (power/wifi): ${p.getString("blk", "kabhi nahi")}\n" +
            "✉ Aakhri email: ${p.getString("last", "koi nahi")}"
    }
}
